#!/bin/sh

java -jar test.jar
